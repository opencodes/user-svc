package com.konze.userservice.exception;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class UserException extends RuntimeException {
    private List<ValidationError> errors;
    private ErrorResponse errorResponse;

    public UserException() {
        super();
    }

    public UserException(String message, Throwable cause) {
        super(message, cause);
    }

    public UserException(String message) {
        super(message);
    }

    public UserException(Throwable cause) {
        super(cause);
    }

    public UserException(String message, String errorCode, String field) {
        super(message);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setMessage(message);
        errorResponse.setErrorCode(errorCode);
        addValidationError(message, field);
        errorResponse.setErrors(errors);
        this.errors = errors;
        this.errorResponse = errorResponse;
    }

    public void addValidationError(String message, String field) {
        if (Objects.isNull(errors)) {
            errors = new ArrayList<>();
        }
        errors.add(new ValidationError(message, field));
    }

    public ErrorResponse getErrorResponse() {
        return errorResponse;
    }

    public void setErrorResponse(ErrorResponse errorResponse) {
        this.errorResponse = errorResponse;
    }
}
