package com.konze.userservice.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.stream.Stream;

public enum UserType {
    ADMIN("ADMIN"),
    INDIVIDUAL_USER("INDIVIDUAL_USER"),
    BUSINESS_USER("BUSINESS_USER");

    private String code;

    private UserType(String code) {
        this.code = code;
    }

    @JsonCreator
    public static UserType decode(final String code) {
       return Stream.of(UserType.values()).filter(targetEnum -> targetEnum.code.equals(code)).findFirst().orElse(null);
    }

    @JsonValue
    public String getCode() {
        return code;
    }
}
