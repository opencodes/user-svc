package com.konze.userservice.repository;


import com.konze.userservice.entity.UserEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface UserRepository extends CrudRepository<UserEntity, String> {

    List<UserEntity> findByEmail(String email);

    List<UserEntity> findByPhoneNo(String phoneNo);


}
