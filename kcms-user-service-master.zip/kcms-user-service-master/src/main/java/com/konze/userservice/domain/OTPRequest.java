package com.konze.userservice.domain;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class OTPRequest {
    @NotNull(message = "email is mandatory")
    @Email
    private String email;

    @NotNull
    @Size(min = 4, max = 4)
    private String otp;

    private OTPFor otpFor;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public OTPFor getOtpFor() {
        return otpFor;
    }

    public void setOtpFor(OTPFor otpFor) {
        this.otpFor = otpFor;
    }
}
