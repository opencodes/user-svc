package com.konze.userservice.domain;

public enum UserStatus {
    REGISTERED,
    ACTIVE,
    INACTIVE
}
