package com.konze.userservice.service;


import com.konze.userservice.domain.*;
import com.konze.userservice.entity.OTPEntity;
import com.konze.userservice.entity.UserEntity;
import com.konze.userservice.exception.ErrorCodes;
import com.konze.userservice.exception.ErrorFields;
import com.konze.userservice.exception.UserException;
import com.konze.userservice.repository.OtpRepository;
import com.konze.userservice.repository.UserRepository;
import com.konze.userservice.util.EmailSender;
import com.konze.userservice.util.OTPGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.transaction.Transactional;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private OtpRepository otpRepository;

    @Value("${profile.service.url}")
    private String profileServiceUrl;

    @Value("${email.service.url}")
    private String emailServiceUrl;

    @Override
    @Transactional
    public UserResponse signupUser(UserRequest userRequest) {
        validateEmailExist(userRequest);
        //validatePhoneExist(user);

        UserEntity userEntity = createUserEntityFromUserRequest(userRequest);
        UserEntity returnedUser = userRepository.save(userEntity);

        saveUserProfile(userEntity.getUserId(), userRequest);

        UserResponse userResponse = userResponseFromUserEntity(returnedUser);
        String generateOTP = generateAndSaveOTP(userResponse, OTPFor.SIGNUP);

        Email emailObj = createEmailObject(userResponse, generateOTP);

        EmailSender.sendEmail(emailObj, emailServiceUrl);

        return userResponse;
    }


    private Email createEmailObject(UserResponse userResponse, String generateOTP) {
        Email emailObj = new Email();
        emailObj.setName(userResponse.getUserId());
        emailObj.setContent("OTP " + generateOTP);
        emailObj.setUserId(userResponse.getUserId());
        emailObj.setSubject("Signup Email");
        EmailList emailList = new EmailList();
        emailList.setEmail(userResponse.getEmail());
        EmailList[] emailListArr = new EmailList[1];
        emailListArr[0] = emailList;
        emailObj.setEmailList(emailListArr);
        return emailObj;
    }

    private String generateAndSaveOTP(UserResponse userResponse, OTPFor otpFor) {

        List<OTPEntity> otpEntities = otpRepository.findByUserId(userResponse.getUserId());

        if (otpEntities.size() > 0) {
            deleteExistingOTPForUser(otpEntities);
        }

        String generateOTP = OTPGenerator.OTP();
        OTPEntity otpEntity = new OTPEntity();
        Date date = Calendar.getInstance().getTime();
        String generatedOtpId = UUID.randomUUID().toString();
        otpEntity.setId(generatedOtpId);
        otpEntity.setGenerated_on(date);
        otpEntity.setValid_upto(date);
        otpEntity.setUserId(userResponse.getUserId());
        otpEntity.setOtp(generateOTP);
        otpEntity.setOtpFor(otpFor.getCode().toString());
        otpRepository.save(otpEntity);
        return generateOTP;
    }

    private void deleteExistingOTPForUser(List<OTPEntity> otpEntities) {
        for (OTPEntity otpEntity : otpEntities) {
            otpRepository.delete(otpEntity);
        }
    }

    @Override
    public UserResponse signIn(String email, String password) {
        List<UserEntity> userEmailExist = userRepository.findByEmail(email);

        if (userEmailExist.size() == 0) {
            throw new UserException("Not a valid email:" + email + " to signin, please signup first", ErrorCodes.USER_SIGNIN_INVALID_CREDENTIALS, ErrorFields.EMAIL);
        } else {
            UserEntity userEntity = userEmailExist.get(0);
            if (!userEntity.getPassword().equals(password)) {
                throw new UserException("Not a valid credentials to signin, please signup first", ErrorCodes.USER_SIGNIN_INVALID_CREDENTIALS, ErrorFields.PASSWORD);
            }
            /*if (userEntity.getUserStatus().equals(UserStatus.REGISTERED.toString())) {
                throw new UserException("User status is registered so verify otp before signin", ErrorCodes.USER_SIGNIN_INACTIVE_USER, ErrorFields.USERSTATUS_REGISTERED);
            }*/
            UserResponse userResponse = userResponseFromUserEntity(userEntity);
            return userResponse;
        }
    }


    @Override
    public UserResponse verify(String emailId, String otp, OTPFor otpFor) {
        List<UserEntity> userEmailExist = userRepository.findByEmail(emailId);

        if (userEmailExist.size() == 0) {
            throw new UserException("User email:" + emailId + " not a valid registered email id.", ErrorCodes.USER_VERIFY_INVALID_INPUT, ErrorFields.EMAIL);
        } else {
            UserEntity userEntity = userEmailExist.get(0);

            List<OTPEntity> otpEntities = otpRepository.findByUserId(userEntity.getUserId());

            if (otpEntities.size() == 0 || !otpEntities.get(otpEntities.size() - 1).getOtp().equals(otp)) {
                throw new UserException("Invalid OTP", ErrorCodes.USER_VERIFY_INVALID_OTP, ErrorFields.OTP);
            }

            if (!otpEntities.get(otpEntities.size() - 1).getOtpFor().equals(otpFor.getCode().toString())) {
                throw new UserException("OTP for reason is not valid ", ErrorCodes.USER_VERIFY_INVALID_OTP, ErrorFields.OTP_FOR);
            }

            userEntity.setUserStatus(UserStatus.ACTIVE.toString());
            UserEntity returnedUser = userRepository.save(userEntity);

            UserResponse userResponse = userResponseFromUserEntity(returnedUser);
            return userResponse;
        }
    }

    @Override
    public String resetPassword(String emailId, String newPassword) {
        List<UserEntity> userEmailExist = userRepository.findByEmail(emailId);
        if (userEmailExist.size() == 0) {
            throw new UserException("User email:" + emailId + " not a valid registered email id.", ErrorCodes.USER_VERIFY_INVALID_INPUT, ErrorFields.EMAIL);
        } else {
            UserEntity userEntity = userEmailExist.get(0);
            userEntity.setPassword(newPassword);
            userRepository.save(userEntity);
        }
        return "password updated successfully!!";
    }

    @Override
    public UserResponse forgotPassword(String emailId) {
        List<UserEntity> userEmailExist = userRepository.findByEmail(emailId);
        if (userEmailExist.size() == 0) {
            throw new UserException("User email:" + emailId + " not a valid registered email id.", ErrorCodes.USER_VERIFY_INVALID_INPUT, ErrorFields.EMAIL);
        } else {
            UserEntity userEntity = userEmailExist.get(0);
            UserResponse userResponse = userResponseFromUserEntity(userEntity);

            String generateOTP = generateAndSaveOTP(userResponse, OTPFor.FORGET_PASSWORD);

            Email emailObj = createEmailObject(userResponse, generateOTP);

            EmailSender.sendEmail(emailObj, this.emailServiceUrl);
            return userResponse;
        }

    }

    @Override
    public String resendOtp(String emailId, OTPFor otpFor) {
        List<UserEntity> userEmailExist = userRepository.findByEmail(emailId);
        if (userEmailExist.size() == 0) {
            throw new UserException("User email:" + emailId + " not a valid registered email id.", ErrorCodes.USER_VERIFY_INVALID_INPUT, ErrorFields.EMAIL);
        } else {
            UserEntity userEntity = userEmailExist.get(0);
            UserResponse userResponse = userResponseFromUserEntity(userEntity);

            String generateOTP = generateAndSaveOTP(userResponse, otpFor);

            return sendEmail(emailId, userResponse, generateOTP);
        }
    }

    private String sendEmail(String emailId, UserResponse userResponse, String generateOTP) {
        Email emailObj = createEmailObject(userResponse, generateOTP);
        EmailSender.sendEmail(emailObj, this.emailServiceUrl);
        return "otp sent successfully on registered email";
    }

    private UserResponse userResponseFromUserEntity(UserEntity userEntity) {
        UserResponse userResponse = new UserResponse();
        userResponse.setUserId(userEntity.getUserId());
        userResponse.setUserStatus(UserStatus.valueOf(userEntity.getUserStatus()));
        userResponse.setUserType(UserType.valueOf(userEntity.getUserType()));
        userResponse.setCreatedBy(userEntity.getCreatedBy());
        userResponse.setUpdatedBy(userEntity.getUpdatedBy());
        userResponse.setCreatedOn(userEntity.getCreatedOn());
        userResponse.setUpdatedOn(userEntity.getUpdatedOn());
        userResponse.setEmail(userEntity.getEmail());
        userResponse.setPhoneNo(userEntity.getPhoneNo());
        userResponse.setCountryCode(userEntity.getCountryCode());
        return userResponse;
    }

    private UserEntity createUserEntityFromUserRequest(UserRequest userRequest) {
        Date date = Calendar.getInstance().getTime();
        String generatedUserId = UUID.randomUUID().toString();
        UserEntity userEntity = new UserEntity();
        userEntity.setUserId(generatedUserId);
        userEntity.setPassword(userRequest.getPassword());

        if (null == userRequest.getUserType()) {
            throw new UserException("Please check user type input", ErrorCodes.USER_SIGNUP_INVALID_INPUT, ErrorFields.USERTYPE);
        }
        if (userRequest.getUserType().equals(UserType.ADMIN)) {
            throw new UserException("Not a valid user type for signup", ErrorCodes.USER_SIGNUP_INVALID_INPUT, ErrorFields.USERTYPE);
        }
        userEntity.setUserType(userRequest.getUserType().toString());
        userEntity.setUserStatus(UserStatus.REGISTERED.toString());
        userEntity.setCreatedBy(generatedUserId);
        userEntity.setUpdatedBy(generatedUserId);
        userEntity.setSecret_key("secret_key");
        userEntity.setCreatedOn(date);
        userEntity.setUpdatedOn(date);
        userEntity.setEmail(userRequest.getEmail());
        userEntity.setPhoneNo(userRequest.getPhoneNo());
        userEntity.setCountryCode(userRequest.getCountryCode());
        return userEntity;
    }

    private void validatePhoneExist(UserRequest user) {
        List<UserEntity> userPhoneExist = userRepository.findByPhoneNo(user.getPhoneNo());
        if (userPhoneExist.size() > 0) {
            throw new UserException("User with phone: " + user.getPhoneNo() + " already signed up, please try to directly sign in with credentials");
        }
    }

    private void validateEmailExist(UserRequest userRequest) {
        List<UserEntity> userEmailExist = userRepository.findByEmail(userRequest.getEmail());
        if (userEmailExist.size() > 0) {
            throw new UserException("User email:" + userRequest.getEmail() + " already signed up", ErrorCodes.USER_SIGNUP_INVALID_INPUT, ErrorFields.USERSTATUS_REGISTERED);
        }
    }


    public void saveUserProfile(String userID, UserRequest userRequest) {
        UserProfile userProfile = new UserProfile();
        userProfile.setFirstName(userRequest.getFirstName());
        userProfile.setMiddleName(userRequest.getMiddleName());
        userProfile.setLastName(userRequest.getLastName());
        userProfile.setUserId(userID);


        EmailList emailList = new EmailList();
        emailList.setEmail(userRequest.getEmail());

        EmailList[] emailListArr = new EmailList[1];
        emailListArr[0] = emailList;
        userProfile.setEmailList(emailListArr);

        if (null == userRequest.getPhoneNo() || userRequest.getPhoneNo().length() == 0) {
            PhoneList[] phoneList = new PhoneList[]{};
            userProfile.setPhoneList(phoneList);
        } else {
            PhoneList phoneList = new PhoneList();
            phoneList.setPhoneNo(userRequest.getPhoneNo());
            phoneList.setCountryCode(userRequest.getCountryCode());

            PhoneList[] phoneListArr = new PhoneList[1];
            phoneListArr[0] = phoneList;
            userProfile.setPhoneList(phoneListArr);
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Content-Type", "application/json");

        HttpEntity<UserProfile> httpEntity = new HttpEntity<>(userProfile, httpHeaders);

        RestTemplate restTemplate = new RestTemplate();
        UserProfile response = restTemplate.postForObject(this.profileServiceUrl, httpEntity, UserProfile.class);
    }


}
