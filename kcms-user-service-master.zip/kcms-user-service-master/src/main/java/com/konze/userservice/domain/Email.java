package com.konze.userservice.domain;

public class Email {

    private String name;
    private EmailList emailList[];
    private String userId;
    private String subject;
    private String content;

    public EmailList[] getEmailList() {
        return emailList;
    }

    public void setEmailList(EmailList[] emailList) {
        this.emailList = emailList;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getName() {
        return name;
    }

    public String getUserId() {
        return userId;
    }

    public String getSubject() {
        return subject;
    }

    public String getContent() {
        return content;
    }
}
