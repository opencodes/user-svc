package com.konze.userservice.util;

public class PasswordGenerator {

}
