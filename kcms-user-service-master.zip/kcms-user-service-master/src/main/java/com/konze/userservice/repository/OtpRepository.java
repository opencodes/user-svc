package com.konze.userservice.repository;


import com.konze.userservice.entity.OTPEntity;
import com.konze.userservice.entity.UserEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.List;


public interface OtpRepository extends CrudRepository<OTPEntity, String> {

    List<OTPEntity> findByUserId(String userId);

}
