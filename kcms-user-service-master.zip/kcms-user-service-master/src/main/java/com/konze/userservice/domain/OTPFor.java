package com.konze.userservice.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.stream.Stream;

public enum OTPFor {
    SIGNIN("SIGNIN"),
    SIGNUP("SIGNUP"),
    FORGET_PASSWORD("FORGET_PASSWORD"),
    RESET_PASSWORD("RESET_PASSWORD");

    private String code;

    private OTPFor(String code) {
        this.code = code;
    }

    @JsonCreator
    public static OTPFor decode(final String code) {
        return Stream.of(OTPFor.values()).filter(targetEnum -> targetEnum.code.equals(code)).findFirst().orElse(null);
    }

    @JsonValue
    public String getCode() {
        return code;
    }
}
