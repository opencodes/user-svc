package com.konze.userservice.domain;

public class UserProfile {
    private String userId;
    private String firstName;
    private String middleName;
    private String lastName;

    private PhoneList phoneList[];
    private EmailList emailList[];

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public PhoneList[] getPhoneList() {
        return phoneList;
    }

    public void setPhoneList(PhoneList[] phoneList) {
        this.phoneList = phoneList;
    }

    public EmailList[] getEmailList() {
        return emailList;
    }

    public void setEmailList(EmailList[] emailList) {
        this.emailList = emailList;
    }
}
