package com.konze.userservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "kcms_otp")
public class OTPEntity implements Serializable {
    @Id
    @Column(name = "id", nullable = false)
    private String id;

    private Date valid_upto;

    private Date generated_on;

    @Column(name = "otp")
    private String otp;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "otp_for")
    private String otpFor;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getValid_upto() {
        return valid_upto;
    }

    public void setValid_upto(Date valid_upto) {
        this.valid_upto = valid_upto;
    }

    public Date getGenerated_on() {
        return generated_on;
    }

    public void setGenerated_on(Date generated_on) {
        this.generated_on = generated_on;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOtpFor() {
        return otpFor;
    }

    public void setOtpFor(String otpFor) {
        this.otpFor = otpFor;
    }
}
