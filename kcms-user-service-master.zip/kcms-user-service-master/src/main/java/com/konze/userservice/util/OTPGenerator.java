package com.konze.userservice.util;

import java.util.Random;

public class OTPGenerator {
    int len = 4;

    public static String OTP() {
        int len = 4;
        // Using numeric values
        String numbers = "0123456789";

        Random rndm_method = new Random();

        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < len; i++) {
            builder.append(numbers.charAt(rndm_method.nextInt(numbers.length())));
        }
        return builder.toString();
    }

    public static void main(String[] args) {
        //System.out.println(OTP());
        //System.out.println("test");
    }
}
