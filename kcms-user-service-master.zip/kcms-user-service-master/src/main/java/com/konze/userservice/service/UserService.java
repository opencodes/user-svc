package com.konze.userservice.service;


import com.konze.userservice.domain.OTPFor;
import com.konze.userservice.domain.UserRequest;
import com.konze.userservice.domain.UserResponse;

public interface UserService {
    UserResponse signupUser(UserRequest userRequest);

    UserResponse signIn(String email, String password);

    UserResponse verify(String emailId, String otp, OTPFor otpFor);

    String resetPassword(String emailId, String newPassword);

    UserResponse forgotPassword(String emailId);

    String resendOtp(String emailId, OTPFor otpFor);
}
