package com.konze.userservice.exception;

/**
 * for HTTP 400 errors
 */
public final class DataFormatException extends RuntimeException {
    public DataFormatException() {
        super();
    }

    public DataFormatException(String message, Throwable cause) {
        super(message, cause);
    }

    public DataFormatException(String message) {
        super(message);
    }

    public DataFormatException(Throwable cause) {
        super(cause);
    }

    public static class RestErrorInfo {
        public final String detail;
        public final String message;

        public RestErrorInfo(Exception ex, String detail) {
            this.message = ex.getLocalizedMessage();
            this.detail = detail;
        }
    }
}