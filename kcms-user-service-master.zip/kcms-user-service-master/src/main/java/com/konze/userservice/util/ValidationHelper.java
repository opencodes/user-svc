package com.konze.userservice.util;

import com.konze.userservice.exception.ErrorCodes;
import com.konze.userservice.exception.ErrorFields;
import com.konze.userservice.exception.UserException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationHelper {

    public static boolean validateEmail(String emailId) {
        String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+(?:\\.[a-zA-Z0-9_!#$%&'*+/=?`{|}~^-]+)*@[a-zA-Z0-9-]+(?:\\.[a-zA-Z0-9-]+)*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(emailId);

        if (null == emailId) {
            throw new UserException("Email is required field", ErrorCodes.USER_SIGNUP_INVALID_INPUT, ErrorFields.EMAIL);
        }

        if (matcher.matches()) {
            return true;
        }
        throw new UserException("Not a valid email format", ErrorCodes.USER_SIGNUP_INVALID_INPUT, ErrorFields.EMAIL);
    }

    public static void validatePhone(String phoneNo) {
        if (null == phoneNo || phoneNo.length() < 10) {
            throw new UserException("phone number should be minimum 10 digits", ErrorCodes.USER_SIGNUP_INVALID_INPUT, ErrorFields.PHONE);
        }
    }
}
