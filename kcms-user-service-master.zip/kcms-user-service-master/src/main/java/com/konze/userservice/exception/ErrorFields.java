package com.konze.userservice.exception;

public interface ErrorFields {

    String EMAIL = "Email";
    String PASSWORD = "Password";
    String PHONE="PhoneNo";
    String USERTYPE="UserType";
    String OTP="otp";
    String OTP_FOR="otp_for";
    String USERSTATUS_REGISTERED="UserStatus.REGISTERED";

}
