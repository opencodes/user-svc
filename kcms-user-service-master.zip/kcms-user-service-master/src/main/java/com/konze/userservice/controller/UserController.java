package com.konze.userservice.controller;

import com.konze.userservice.domain.*;
import com.konze.userservice.exception.ErrorCodes;
import com.konze.userservice.exception.ErrorFields;
import com.konze.userservice.exception.UserException;
import com.konze.userservice.service.UserService;
import com.konze.userservice.util.ValidationHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping(value = "/user-service")
@CrossOrigin
public class UserController {
    @Autowired
    private UserService userService;

    @RequestMapping(value = "/signup", method = RequestMethod.POST)
    public ResponseEntity<UserResponse> signUp(@Valid @RequestBody UserRequest userRequest) {
        if (null != userRequest.getPhoneNo() && userRequest.getPhoneNo().length() > 0) {
            ValidationHelper.validatePhone(userRequest.getPhoneNo());
        }
        ValidationHelper.validateEmail(userRequest.getEmail());
        UserResponse createdUserResponse = userService.signupUser(userRequest);
        return new ResponseEntity<UserResponse>(createdUserResponse, HttpStatus.CREATED);
    }

    @RequestMapping(value = "/signin", method = RequestMethod.POST)
    public ResponseEntity<UserResponse> signIn(@RequestBody UserRequest userRequest) {
        System.out.println("testing .");
        if (null == userRequest || null == userRequest.getEmail() || null == userRequest.getPassword()) {
            throw new UserException("user request is not valid ", ErrorCodes.USER_SIGNIN_INVALID_CREDENTIALS, ErrorFields.EMAIL);
        }
        ValidationHelper.validateEmail(userRequest.getEmail());
        UserResponse signedUserResponse = userService.signIn(userRequest.getEmail(), userRequest.getPassword());
        return new ResponseEntity<UserResponse>(signedUserResponse, HttpStatus.OK);
    }

    @RequestMapping(value = "/verify", method = RequestMethod.POST)
    public ResponseEntity<UserResponse> verify(@Valid @RequestBody OTPRequest otpRequest) {
        ValidationHelper.validateEmail(otpRequest.getEmail());
        UserResponse verifiedUserResponse = userService.verify(otpRequest.getEmail(), otpRequest.getOtp(), otpRequest.getOtpFor());
        return new ResponseEntity<UserResponse>(verifiedUserResponse, HttpStatus.OK);
    }

    @RequestMapping(value = "/forgotpassword", method = RequestMethod.POST)
    public ResponseEntity<UserResponse> forgotPassword(@Valid @RequestBody EmailRequest emailRequest) {
        ValidationHelper.validateEmail(emailRequest.getEmail());
        UserResponse verifiedUserResponse = userService.forgotPassword(emailRequest.getEmail());
        return new ResponseEntity<UserResponse>(verifiedUserResponse, HttpStatus.OK);
    }

    @RequestMapping(value = "/resendotp", method = RequestMethod.POST)
    public ResponseEntity<Response> resendOtp(@RequestBody OTPRequest otpRequest) {
        ValidationHelper.validateEmail(otpRequest.getEmail());
        String verifiedUserResponse = userService.resendOtp(otpRequest.getEmail(), otpRequest.getOtpFor());
        Response response = new Response();
        response.setMessage(verifiedUserResponse);
        return new ResponseEntity<Response>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/resetpassword", method = RequestMethod.POST)
    public ResponseEntity<Response> resetPassword(@Valid @RequestBody PasswordRequest passwordRequest) {
        ValidationHelper.validateEmail(passwordRequest.getEmail());
        String passwordUpdated = userService.resetPassword(passwordRequest.getEmail(), passwordRequest.getPassword());
        Response response = new Response();
        response.setMessage(passwordUpdated);
        return new ResponseEntity<Response>(response, HttpStatus.OK);
    }
}
