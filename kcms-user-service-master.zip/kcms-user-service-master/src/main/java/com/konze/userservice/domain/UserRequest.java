package com.konze.userservice.domain;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class UserRequest {
    @NotNull(message = "first name is mandatory")
    private String firstName;
    private String middleName;
    @NotNull(message = "last name is mandatory")
    private String lastName;

    @NotNull(message = "email is mandatory")
    @Email
    private String email;

    @NotNull(message = "phone number is mandatory")
    @Size(min = 10, max = 10)
    private String phoneNo;

    @NotNull(message = "country code is mandatory")
    @Size(min = 3, max = 5)
    private String countryCode;

    private UserType userType;

    @NotNull
    @Size(min = 8, max = 15)
    private String password;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
