package com.konze.userservice.util;

import com.konze.userservice.domain.Email;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

public class EmailSender {

    public static void sendEmail(Email email, String url ) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Content-Type", "application/json");

        HttpEntity<Email> httpEntity = new HttpEntity<>(email, httpHeaders);

        RestTemplate restTemplate = new RestTemplate();
        Email response = restTemplate.postForObject(url, httpEntity, Email.class);
        //log.info("email sent successfully");
    }

    public static void main(String[] args) {
        /*Email email = new Email();
        email.setName("Anoop");
        email.setContent("OTP 5457");
        email.setUserId("456546546");
        email.setSubject("Signup Email");

        EmailList emailList = new EmailList();
        emailList.setEmail("test.it@gmail.com");

        EmailList[] emailListArr = new EmailList[1];
        emailListArr[0] = emailList;
        email.setEmailList(emailListArr);
        EmailSender.sendEmail(email);*/
    }
}
